import React, { useState, useEffect, useRef } from 'react';
import VanGoghCanvas from './components/VanGoghCanvas';
import Controls from './components/Controls';
import { useAudioVisualizer } from './hooks/useAudioVisualizer';
import { ArtConfig } from './types';

// Default configuration tuned for "Linear Sketch / Clarity"
const DEFAULT_CONFIG: ArtConfig = {
  particleCount: 30000, 
  baseSpeed: 0.5, // Faster speed to draw lines
  colorPalette: [], // Empty means "True Color"
  strokeWidth: 3.0, // Thinner for sharper definition
  flowScale: 0.01, 
  fadeRate: 0.22, 
  themeName: 'Linear Clarity',
  description: 'High definition lines following contours. Sharper, sketch-like quality.'
};

const App: React.FC = () => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [config, setConfig] = useState<ArtConfig>(DEFAULT_CONFIG);
  const [isStarted, setIsStarted] = useState(false);
  
  const { 
    initializeAudio, 
    connectMicrophone, 
    analyze, 
    audioData 
  } = useAudioVisualizer();

  const animationFrameRef = useRef<number>(0);

  // Init Camera & Microphone
  const startExperience = async () => {
    try {
      initializeAudio();
      
      // Request both video and audio
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: {
            width: { ideal: 640 },
            height: { ideal: 480 },
            facingMode: "user"
        }, 
        audio: true 
      });
      
      setStream(mediaStream);
      
      // Connect microphone stream to visualizer
      connectMicrophone(mediaStream);

      setIsStarted(true);
      
      // Start analysis loop
      const loop = () => {
        analyze();
        animationFrameRef.current = requestAnimationFrame(loop);
      };
      loop();
    } catch (err) {
      console.error("Error accessing media devices:", err);
      alert("Microphone and Camera access are required for this experience.");
    }
  };

  const handleUpdateConfig = (newConfig: Partial<ArtConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  };

  useEffect(() => {
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  if (!isStarted) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-900 text-white p-4">
        <div className="max-w-2xl text-center space-y-8">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent pb-2">
            Van Gogh Flow
          </h1>
          <p className="text-xl text-slate-300">
            Real-time Audio-Visual Particle Renderer powered by Gemini 3.
          </p>
          <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700 text-left space-y-4">
            <h3 className="text-lg font-semibold text-purple-400">How it works:</h3>
            <ul className="list-disc list-inside space-y-2 text-slate-300">
              <li><strong>Contour Flow:</strong> Particles follow the natural edges of the video.</li>
              <li><strong>Turbulence:</strong> Backgrounds swirl like the Starry Night sky.</li>
              <li><strong>Impasto Texture:</strong> Thick, heavy brush strokes for an oil painting feel.</li>
            </ul>
          </div>
          <button 
            onClick={startExperience}
            className="px-8 py-4 bg-purple-600 hover:bg-purple-700 rounded-full font-bold text-lg shadow-lg shadow-purple-500/30 transition-all hover:scale-105"
          >
            Start Experience (Cam + Mic)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-900">
      {/* The Visualizer */}
      <VanGoghCanvas 
        config={config} 
        audioData={audioData} 
        videoStream={stream} 
      />

      {/* UI Layer */}
      <Controls 
        currentConfig={config}
        onUpdateConfig={handleUpdateConfig}
      />
      
      {/* Footer / Branding */}
      <div className="fixed bottom-4 left-4 z-40 text-white/50 text-xs pointer-events-none">
        <p>Van Gogh Flow v3.2 • High Definition Linear</p>
      </div>
    </div>
  );
};

export default App;