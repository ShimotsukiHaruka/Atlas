import React, { useRef, useEffect } from 'react';
import { ArtConfig, AudioData, Particle } from '../types';

interface VanGoghCanvasProps {
  config: ArtConfig;
  audioData: AudioData;
  videoStream: MediaStream | null;
}

const VanGoghCanvas: React.FC<VanGoghCanvasProps> = ({ config, audioData, videoStream }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hiddenVideoRef = useRef<HTMLVideoElement>(null);
  const hiddenCanvasRef = useRef<HTMLCanvasElement>(null); 
  const requestRef = useRef<number>(0);
  const particlesRef = useRef<Particle[]>([]);
  
  // Initialize video stream
  useEffect(() => {
    if (hiddenVideoRef.current && videoStream) {
      hiddenVideoRef.current.srcObject = videoStream;
      hiddenVideoRef.current.play().catch(e => console.error("Video play error:", e));
    }
  }, [videoStream]);

  // Initialize Particles
  useEffect(() => {
    const initParticles = () => {
      const particles: Particle[] = [];
      const { width, height } = canvasRef.current?.getBoundingClientRect() || { width: 800, height: 600 };
      
      for (let i = 0; i < config.particleCount; i++) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: 0,
          vy: 0,
          life: Math.random() * 100,
          maxLife: 50 + Math.random() * 100,
          color: '#ffffff',
          size: Math.random() * config.strokeWidth + 0.5
        });
      }
      particlesRef.current = particles;
    };
    
    initParticles();
  }, [config.particleCount, config.strokeWidth]);

  // Main Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d', { alpha: false }); 
    const hiddenCanvas = hiddenCanvasRef.current;
    const hiddenCtx = hiddenCanvas?.getContext('2d', { willReadFrequently: true });
    const video = hiddenVideoRef.current;

    if (!canvas || !ctx || !hiddenCanvas || !hiddenCtx || !video) return;

    // Fixed High Resolution for sampling
    const SAMPLE_W = 480; 
    const SAMPLE_H = 360;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      hiddenCanvas.width = SAMPLE_W;
      hiddenCanvas.height = SAMPLE_H;
    };
    window.addEventListener('resize', resize);
    resize();

    // Pre-allocate intensity array to avoid GC in loop
    const intensity = new Float32Array(SAMPLE_W * SAMPLE_H);

    const animate = () => {
      // 1. Draw video to hidden canvas
      if (video.readyState >= video.HAVE_CURRENT_DATA) {
        hiddenCtx.drawImage(video, 0, 0, SAMPLE_W, SAMPLE_H);
      }

      // 2. Get Data
      const currFrame = hiddenCtx.getImageData(0, 0, SAMPLE_W, SAMPLE_H);
      const data = currFrame.data;

      // Calculate intensity map for gradient detection WITH CONTRAST BOOST
      for (let i = 0; i < SAMPLE_W * SAMPLE_H; i++) {
        const r = data[i * 4];
        const g = data[i * 4 + 1];
        const b = data[i * 4 + 2];
        // Standard grayscale
        let gray = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        
        // Contrast S-Curve to sharpen edges
        // This pushes darks darker and lights lighter
        gray = gray < 0.5 ? 2 * gray * gray : -1 + (4 - 2 * gray) * gray;
        
        intensity[i] = gray;
      }

      // 3. Fade Background
      // Use a slightly lighter fade to keep brightness high
      ctx.fillStyle = `rgba(10, 15, 30, ${config.fadeRate})`; 
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Set styles for "Linear Sketch" look
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = config.strokeWidth; 

      // 4. Update Particles
      const particles = particlesRef.current;
      const len = particles.length;
      const width = canvas.width;
      const height = canvas.height;

      const hasPalette = config.colorPalette && config.colorPalette.length > 0;
      const palette = config.colorPalette;

      // Scaling factors
      const scaleX = SAMPLE_W / width;
      const scaleY = SAMPLE_H / height;

      // Audio influence
      const audioBass = audioData ? audioData.bass / 255 : 0;
      const audioTreble = audioData ? audioData.treble / 255 : 0;
      
      // Global time for turbulence
      const time = Date.now() * 0.0005; 

      for (let i = 0; i < len; i++) {
        const p = particles[i];

        // --- SAMPLING ---
        const sx = Math.floor(p.x * scaleX);
        const sy = Math.floor(p.y * scaleY);
        
        let idx = 0;
        let brightness = 0;
        let r = 0, g = 0, b = 0;

        if (sx >= 0 && sx < SAMPLE_W && sy >= 0 && sy < SAMPLE_H) {
            idx = sy * SAMPLE_W + sx;
            brightness = intensity[idx];
            const pIdx = idx * 4;
            r = data[pIdx];
            g = data[pIdx+1];
            b = data[pIdx+2];
        }

        // --- GRADIENT CALCULATION (Contour Following) ---
        // Get neighbors (clamped)
        const left = sx > 0 ? intensity[idx - 1] : brightness;
        const right = sx < SAMPLE_W - 1 ? intensity[idx + 1] : brightness;
        const top = sy > 0 ? intensity[idx - SAMPLE_W] : brightness;
        const bottom = sy < SAMPLE_H - 1 ? intensity[idx + SAMPLE_W] : brightness;

        // Sobel-like gradient
        const dx = right - left;
        const dy = bottom - top;

        // Flow along the edge (perpendicular to gradient)
        let angle = Math.atan2(dy, dx) + Math.PI / 2;

        const gradientMag = Math.abs(dx) + Math.abs(dy);

        // --- TURBULENCE FOR FLAT AREAS ---
        // If gradient is weak (flat color), use swirl noise (Starry Night sky effect)
        if (gradientMag < 0.05) {
           const scale = 0.01;
           const swirl = Math.sin(p.x * scale + time) + Math.cos(p.y * scale + time) + audioBass * 2;
           angle = swirl * Math.PI;
        }

        // Audio extra turbulence
        angle += (Math.random() - 0.5) * audioTreble * 0.5;

        // --- PHYSICS ---
        // Constant slow speed but slightly faster for drawing lines
        const speed = config.baseSpeed + (brightness * 0.8); 

        p.vx += Math.cos(angle) * 0.05; // Acceleration
        p.vy += Math.sin(angle) * 0.05;

        // Friction 
        p.vx *= 0.90; 
        p.vy *= 0.90;

        // Cap speed
        const currSpeed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
        if (currSpeed > 3) {
             p.vx = (p.vx / currSpeed) * 3;
             p.vy = (p.vy / currSpeed) * 3;
        }

        p.x += p.vx + Math.cos(angle) * speed;
        p.y += p.vy + Math.sin(angle) * speed;

        // Wrap
        if (p.x < 0) p.x = width;
        else if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        else if (p.y > height) p.y = 0;

        // --- COLOR & RENDERING ---
        ctx.beginPath();
        
        // Dynamic Opacity: Stronger edges = more opaque lines
        const edgeOpacity = Math.min(1, 0.3 + gradientMag * 5); 
        ctx.globalAlpha = edgeOpacity;

        if (hasPalette) {
          const pIdx = Math.floor(brightness * palette.length);
          const safeIdx = Math.min(pIdx, palette.length - 1);
          ctx.strokeStyle = palette[safeIdx];
        } else {
          // Brightness Boost + Contrast
          // Make darks darker (sketch feel) and lights brighter
          const boost = 1.4; 
          
          let finalR = r * boost;
          let finalG = g * boost;
          let finalB = b * boost;

          ctx.strokeStyle = `rgb(${finalR}, ${finalG}, ${finalB})`;
        }

        // LINE DRAWING: Longer trails = more "Line sense"
        // Scale trail by speed to make fast moving lines look longer
        const trailLen = 8.0; 
        ctx.moveTo(p.x - p.vx * trailLen, p.y - p.vy * trailLen); 
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
        
        ctx.globalAlpha = 1.0; // Reset
      }

      requestRef.current = requestAnimationFrame(animate);
    };

    requestRef.current = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener('resize', resize);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [config, audioData]);

  return (
    <div className="fixed inset-0 z-0">
      <video ref={hiddenVideoRef} className="hidden" muted playsInline />
      <canvas ref={hiddenCanvasRef} className="hidden" />
      <canvas ref={canvasRef} className="block w-full h-full" />
    </div>
  );
};

export default VanGoghCanvas;