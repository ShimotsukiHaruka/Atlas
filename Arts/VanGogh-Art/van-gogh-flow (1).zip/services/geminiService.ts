import { GoogleGenAI, Type } from "@google/genai";
import { ArtConfig } from '../types';

// Use gemini-2.5-flash for speed and efficiency in UI interaction
const MODEL_NAME = 'gemini-2.5-flash';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateArtTheme = async (userPrompt: string): Promise<Partial<ArtConfig>> => {
  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Generate a visual art configuration based on this mood/theme: "${userPrompt}". 
      The palette should contain 5 hex color codes. 
      Particle count between 20000 and 40000. 
      Base speed between 0.3 and 1.5.
      Flow scale between 0.001 and 0.01.
      Fade rate between 0.1 and 0.3.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            themeName: { type: Type.STRING },
            description: { type: Type.STRING },
            colorPalette: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            particleCount: { type: Type.NUMBER },
            baseSpeed: { type: Type.NUMBER },
            flowScale: { type: Type.NUMBER },
            fadeRate: { type: Type.NUMBER }
          },
          required: ["themeName", "colorPalette", "baseSpeed", "particleCount"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as Partial<ArtConfig>;
    }
    throw new Error("No response text from Gemini");
  } catch (error) {
    console.error("Failed to generate theme:", error);
    // Fallback if API fails
    return {
      themeName: "Fallback Blue",
      description: "A default cool blue theme due to network error.",
      colorPalette: ["#0f172a", "#334155", "#64748b", "#94a3b8", "#e2e8f0"],
      baseSpeed: 0.5,
      particleCount: 30000,
      strokeWidth: 3.0
    };
  }
};