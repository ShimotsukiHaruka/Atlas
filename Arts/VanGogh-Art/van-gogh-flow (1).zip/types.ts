export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
}

export interface AudioData {
  bass: number;   // 0 - 255
  mid: number;    // 0 - 255
  treble: number; // 0 - 255
  volume: number; // 0 - 1 (normalized)
}

export interface ArtConfig {
  particleCount: number;
  baseSpeed: number;
  colorPalette: string[];
  strokeWidth: number;
  flowScale: number; // How much the noise/image affects direction
  fadeRate: number; // Trail length (lower is longer trails)
  themeName: string;
  description: string;
}

export enum AppState {
  IDLE,
  INITIALIZING,
  RUNNING,
  ERROR
}
