import React, { useState } from 'react';
import { ArtConfig } from '../types';
import { generateArtTheme } from '../services/geminiService';

interface ControlsProps {
  onUpdateConfig: (config: Partial<ArtConfig>) => void;
  currentConfig: ArtConfig;
}

// Preset Palettes (Sorted Dark to Light for Luminance Mapping)
const PALETTES = {
  original: [],
  starryNight: ['#0B1026', '#2B3266', '#4B5C99', '#FFD700', '#FFFFFF'], // Dark Blue -> Gold/White
  sunflowers: ['#3E2723', '#2E7D32', '#F9A825', '#FFEB3B', '#FFF9C4'],  // Brown/Green -> Yellow
  wheatfield: ['#1A237E', '#283593', '#FBC02D', '#FFEB3B', '#FFFFFF'],   // Deep Blue -> Wheat Gold
  selfPortrait: ['#002233', '#004455', '#88AA99', '#DDAA77', '#FFCCAA']  // Teal -> Skin Tones
};

const Controls: React.FC<ControlsProps> = ({ onUpdateConfig, currentConfig }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGeminiGenerate = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    try {
      const newConfig = await generateArtTheme(prompt);
      onUpdateConfig(newConfig);
      setPrompt('');
    } finally {
      setIsGenerating(false);
    }
  };

  const applyPalette = (name: string, palette: string[]) => {
    onUpdateConfig({ 
      colorPalette: palette,
      themeName: name,
      description: palette.length === 0 ? "Real-time colors from video feed." : `Applied ${name} color scheme.`
    });
  };

  return (
    <div className={`fixed top-4 right-4 z-50 transition-all duration-300 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="absolute right-full top-0 mr-2 bg-white/10 backdrop-blur-md p-2 rounded-l-lg text-white hover:bg-white/20"
      >
        {isOpen ? '→' : '←'}
      </button>

      <div className="bg-slate-900/80 backdrop-blur-lg border border-slate-700 p-6 rounded-lg w-80 shadow-2xl text-slate-200">
        <h2 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
          Van Gogh Flow
        </h2>

        <div className="space-y-6">
          {/* Audio Status Section */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">Audio Source</label>
            <div className="flex items-center gap-2 border border-slate-600 rounded-lg p-3 bg-slate-800/50">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
              <span className="text-sm font-medium">Microphone Live</span>
            </div>
          </div>

          {/* Color Palettes */}
          <div className="space-y-2 pt-4 border-t border-slate-700">
            <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">Van Gogh Palettes</label>
            <div className="grid grid-cols-2 gap-2">
               <button 
                onClick={() => applyPalette("True Color", PALETTES.original)}
                className={`px-2 py-2 rounded text-xs font-medium transition-colors border ${currentConfig.colorPalette.length === 0 ? 'bg-white text-slate-900 border-white' : 'bg-slate-800 border-slate-600 hover:bg-slate-700'}`}
              >
                🎥 True Color
              </button>
              <button 
                onClick={() => applyPalette("Starry Night", PALETTES.starryNight)}
                className="px-2 py-2 rounded text-xs font-medium bg-slate-800 border border-slate-600 hover:bg-indigo-900/50 hover:border-indigo-400 transition-colors"
              >
                🌃 Starry Night
              </button>
              <button 
                onClick={() => applyPalette("Sunflowers", PALETTES.sunflowers)}
                className="px-2 py-2 rounded text-xs font-medium bg-slate-800 border border-slate-600 hover:bg-yellow-900/30 hover:border-yellow-400 transition-colors"
              >
                🌻 Sunflowers
              </button>
              <button 
                onClick={() => applyPalette("Wheatfield", PALETTES.wheatfield)}
                className="px-2 py-2 rounded text-xs font-medium bg-slate-800 border border-slate-600 hover:bg-blue-900/40 hover:border-blue-400 transition-colors"
              >
                🌾 Wheatfield
              </button>
              <button 
                onClick={() => applyPalette("Self Portrait", PALETTES.selfPortrait)}
                className="px-2 py-2 rounded text-xs font-medium bg-slate-800 border border-slate-600 hover:bg-teal-900/40 hover:border-teal-400 transition-colors"
              >
                🎨 Self Portrait
              </button>
            </div>
          </div>

          {/* Gemini AI Section */}
          <div className="space-y-3 pt-4 border-t border-slate-700">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">AI Curator</span>
              <span className="bg-blue-500 text-[10px] px-1.5 py-0.5 rounded text-white font-bold">GEMINI 3</span>
            </div>
            <p className="text-xs text-slate-400">Describe a mood (e.g., "Cyberpunk", "Soft Rain") to adjust movement.</p>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Enter a mood..."
                className="bg-slate-800 border border-slate-600 rounded px-3 py-2 text-sm w-full focus:outline-none focus:border-purple-500"
                onKeyDown={(e) => e.key === 'Enter' && handleGeminiGenerate()}
              />
              <button 
                onClick={handleGeminiGenerate}
                disabled={isGenerating}
                className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-2 rounded text-sm font-medium disabled:opacity-50 transition-colors"
              >
                {isGenerating ? '...' : 'Go'}
              </button>
            </div>
          </div>

          {/* Current Stats */}
          <div className="pt-4 border-t border-slate-700 text-xs text-slate-400 space-y-1">
             <div className="flex justify-between">
              <span>Theme:</span>
              <span className="text-white font-medium truncate ml-2">{currentConfig.themeName}</span>
            </div>
            <div className="flex justify-between">
              <span>Particles:</span>
              <span className="text-white font-medium">{currentConfig.particleCount}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Controls;