import { useState, useRef, useCallback } from 'react';
import { AudioData } from '../types';

export const useAudioVisualizer = () => {
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | MediaElementAudioSourceNode | null>(null);
  const [audioData, setAudioData] = useState<AudioData>({ bass: 0, mid: 0, treble: 0, volume: 0 });
  const dataArrayRef = useRef<Uint8Array | null>(null);

  const initializeAudio = useCallback(() => {
    if (audioContext) return;
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const anal = ctx.createAnalyser();
    anal.fftSize = 1024; 
    anal.smoothingTimeConstant = 0.8;
    setAudioContext(ctx);
    setAnalyser(anal);
    dataArrayRef.current = new Uint8Array(anal.frequencyBinCount);
  }, [audioContext]);

  const connectMicrophone = useCallback((stream: MediaStream) => {
    if (!audioContext || !analyser) return;

    if (audioContext.state === 'suspended') {
        audioContext.resume();
    }

    if (sourceRef.current) {
        sourceRef.current.disconnect();
    }

    // Create a source from the microphone stream
    const source = audioContext.createMediaStreamSource(stream);
    source.connect(analyser);
    // Note: Do NOT connect microphone to destination (speakers) to avoid feedback loop
    sourceRef.current = source;
  }, [audioContext, analyser]);

  // Kept for backward compatibility if needed, though App.tsx uses connectMicrophone now
  const connectAudioElement = useCallback((audioElement: HTMLAudioElement) => {
    if (!audioContext || !analyser) return;
    
    if (audioContext.state === 'suspended') {
      audioContext.resume();
    }

    if (sourceRef.current) {
        sourceRef.current.disconnect();
    }

    const source = audioContext.createMediaElementSource(audioElement);
    source.connect(analyser);
    analyser.connect(audioContext.destination);
    sourceRef.current = source;
  }, [audioContext, analyser]);

  const analyze = useCallback(() => {
    if (!analyser || !dataArrayRef.current) return { bass: 0, mid: 0, treble: 0, volume: 0 };

    analyser.getByteFrequencyData(dataArrayRef.current);

    const length = dataArrayRef.current.length;
    // Frequency bands
    const bassLimit = Math.floor(length * 0.1);
    const midLimit = Math.floor(length * 0.4);

    let bassSum = 0;
    let midSum = 0;
    let trebleSum = 0;

    for (let i = 0; i < length; i++) {
      const val = dataArrayRef.current[i];
      if (i < bassLimit) bassSum += val;
      else if (i < midLimit) midSum += val;
      else trebleSum += val;
    }

    const bass = bassSum / bassLimit;
    const mid = midSum / (midLimit - bassLimit);
    const treble = trebleSum / (length - midLimit);
    const volume = (bass + mid + treble) / 3 / 255;

    const data = { bass, mid, treble, volume };
    setAudioData(data);
    return data;
  }, [analyser]);

  return {
    initializeAudio,
    connectAudioElement,
    connectMicrophone,
    analyze,
    audioData,
    audioContext
  };
};